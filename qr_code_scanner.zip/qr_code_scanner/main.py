# install few libraries
# pip install qrcode
# pip install image

# developer- shailendra kumar
# fb- https://www.facebook.com/shailendrakr007/

import qrcode
import imageio_ffmpeg
qr = qrcode.QRCode(
    version= 15,
    box_size= 10,
    border= 5
)

data = "https://www.youtube.com/channel/UC_7NLLEcj-EJUAjBZdlmsfQ"

qr.add_data(data)
qr.make(fit=True)
img = qr.make_image(fill="black", back_color = "white")
img.save("test.png")